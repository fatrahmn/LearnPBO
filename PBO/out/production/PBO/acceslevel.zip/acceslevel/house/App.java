package acceslevel.house;

public class App {
    public static void main(String[] args) {
        Mom anna = new Mom();
/*        System.out.println(anna.money);
        System.out.println(anna.isOut);*/

        System.out.println(anna.getMoney());
        Sis anny = new Sis();
        System.out.println(anny.getMoney());

    }
}
