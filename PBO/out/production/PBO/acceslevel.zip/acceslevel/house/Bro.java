package acceslevel.house;

import acceslevel.office.Dad;

public class Bro extends Dad {
    String car = super.car;
}
