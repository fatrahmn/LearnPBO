package acceslevel.office;

public class DadFriend {
    //String car = super.car;

    void leaveWork() {
        System.out.println("bye!!");
    }

    void leaveWork(String time) {
        System.out.println(time + " Byee!!");
    }

    void leaveWork(int time) {
        System.out.println("its " + time + " o clock, byee!!");
    }
}

