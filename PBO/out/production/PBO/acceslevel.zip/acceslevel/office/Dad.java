package acceslevel.office;

public class Dad {
    protected String car = "Sedand";
}
